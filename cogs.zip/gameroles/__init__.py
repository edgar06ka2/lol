from .gameroles import GameRoles

def setup(bot):
	bot.add_cog(GameRoles(bot))
