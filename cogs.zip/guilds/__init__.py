from .guilds import guild


def setup(bot):
    bot.add_cog(guild(bot))