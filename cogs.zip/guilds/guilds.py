import discord
import math
import asyncio
from discord.utils import get
from discord import Client
from redbot.core import bank, checks, commands, Config
from redbot.core.i18n import Translator, cog_i18n
from redbot.core.utils.menus import start_adding_reactions, menu, DEFAULT_CONTROLS
from redbot.core.utils.mod import get_audit_reason
from redbot.core.utils import chat_formatting as chat
from tabulate import tabulate
from pymongo import MongoClient

REACTIONS = {"\N{WHITE HEAVY CHECK MARK}": True, "\N{CROSS MARK}": False}

_ = Translator("PersonalRoles", __file__)

cliente = MongoClient()
db = cliente["guilds"]

async def has_guild(ctx):
	return ctx.guild.get_role(await ctx.cog.config.member(ctx.author).guild())


class guild(commands.Cog):
	"""Гильдии"""

	def __init__(self, bot):
		self.bot = bot
		self.config = Config.get_conf(self, identifier=7802285242)
		default_guild = {
		"cost": [],
		"pos": [],
		"enable": True
		}
		default_member = {
		"guild": None,
		"guildrole": []
		}
		self.config.init_custom("Guilds", 1)
		self.config.register_custom(
		"Guilds",
		guildname=None,
		guildmoney=None,
		guildowner=None,
		members=None
		)
		self.config.register_member(**default_member)
		self.config.register_guild(**default_guild)

	@commands.group()
	@commands.guild_only()
	async def guild(self, ctx):
		"""Гильдии"""
		pass
	@guild.command()
	@commands.guild_only()
	async def create(self, ctx, *, guild_name: str):
		"""Создать гильдию"""
		cfg = self.config
		cost = await cfg.guild(ctx.guild).cost()
		if cost == []:
			await ctx.send(
				chat.error(
					 (
						"Не поставлена цена на гильдии"
					)
				)
			)
			return
		member = ctx.author
		user = ctx.author
		currency = await bank.get_currency_name(ctx.guild)
		guild = ctx.guild
		guildtag = ctx.guild.id
		pos = await self.config.guild(ctx.guild).pos()
		if pos == '[]':
			await ctx.send(
				chat.error(
						(
						"Не поставлена пизиция ролей в discord анархии"
					)
				)
			)
		m = await ctx.send(
			f"Хочеш создать клан за {cost} {currency}?"
		)
		start_adding_reactions(m, REACTIONS.keys())

		try:

			def predicate(r, u):
				return u == ctx.author and r.message.id == m.id and r.emoji in REACTIONS

			react, _user = await ctx.bot.wait_for(
				"reaction_add", check=predicate, timeout=30
			)
		except asyncio.TimeoutError:
			return await ctx.send("Я не могу ждать вечно.")

		confirm = REACTIONS[react.emoji]

		if confirm:
			try:
				await bank.withdraw_credits(ctx.author, cost)
			except ValueError:
				return await ctx.send(f"У тебя нету столько {currency}!")

			try:
				cfg = self.config
				role = await guild.create_role(name=guild_name,reason=get_audit_reason(ctx.author, ("Guilds")))
				await cfg.custom("Guilds", role.id).set(
					{
						"guildname": guild_name,
						"guildmoney": 0,
						"guildowner": ctx.author.id
					}
				)
				await cfg.custom("Guilds", role.id).set(
					{
						"members": ctx.author.id
					}
				)
				await member.add_roles(role, reason=get_audit_reason(ctx.author, ("Guilds")))
				await cfg.member(ctx.author).guild.set(role.id)
				await cfg.member(ctx.author).guildrole.set("Owner")
				await role.edit(position=pos)
				
			except discord.Forbidden:
				ctx.command.reset_cooldown(ctx)
				await ctx.send(
					chat.error(
						(
							"Нет прав"
						)
					)
				)
			else:
				await ctx.send(f"Гильдия создана.")

		else:
			await ctx.send("Ок,покупка отклонена")

	@guild.command()
	@commands.guild_only()
	@commands.check(has_guild)
	async def disband(self, ctx):
		"""Распустить Гильдию"""
		guildid = ctx.guild.id
		cfg = self.config
		role = await cfg.member(ctx.author).guild()
		govno = await self.config.member(ctx.author).guildrole()
		if govno == "Owner":
			pass
		else:
			await ctx.send(
				"Ты не создатель гильдии"
			)
			return
		try:
			await cfg.custom("Guilds", role).clear()
			await cfg.member(ctx.author).clear()
			role = ctx.guild.get_role(role)
			await role.delete(reason=get_audit_reason(ctx.author, ("Guilds")))
		except discord.HTTPException:
			await ctx.send(
				"Ошибка. Обратитесь к <@238375974226362368>"
			)
		else:
			await ctx.send(f"Гильдия успешно распущенна")
	@commands.cooldown(1, 30, commands.BucketType.user)
	@guild.command()
	@commands.guild_only()
	@commands.check(has_guild)
	async def invite(self, ctx, member: discord.Member):
		"""Добавить Учасника в Гильдию"""
		cfg = self.config
		role = await cfg.member(ctx.author).guild()
		roleid = await cfg.member(ctx.author).guild()
		guild__name = ctx.guild.get_role(role)
		lolka = ctx.guild.get_role(await self.config.member(member).guild())
		if lolka in member.roles:
			await ctx.send(
				"Этот учасник уже в гильдии"
			)
			return
		else:
			pass
		lolka = ctx.guild.get_role(await self.config.member(ctx.author).guild())
		if lolka in member.roles:
			await ctx.send(
				"Этот учасник уже в гильдии"
			)
			return
		else:
			pass
		m = await member.send(f"Вас пригласили в гильдию {guild__name}.Принять приглашение?")
		start_adding_reactions(m, REACTIONS.keys())

		try:

			def predicate(r, u):
				return u == member and r.message.id == m.id and r.emoji in REACTIONS
			await ctx.send("Приглашение отправлено")

			react, _user = await ctx.bot.wait_for(
				"reaction_add", check=predicate, timeout=60
			)
		except asyncio.TimeoutError:
			return await member.send("Я не буду ждать вечно.")

		confirm = REACTIONS[react.emoji]

		if confirm:
			try:
				await cfg.member(member).guild.set(role)
				await cfg.custom("Guilds", roleid).set(
					{
						"members": member
					}
				)
				role = ctx.guild.get_role(role)
				await member.add_roles(role, reason=get_audit_reason(ctx.author, ("Guilds")))

			except discord.Forbidden:
				ctx.command.reset_cooldown(ctx)
				await ctx.send(
					chat.error(
						_(
							"Нет прав"
						)
					)
				)
			else:
				await member.send("Приглашение Принято.")
				await ctx.send(f"{member} Принял приглашение")

		else:
			await member.send("Приглошение Отклонено.")
			await ctx.send(f"{member} Отклонил приглашение")
	@commands.cooldown(1, 15, commands.BucketType.user)
	@guild.command()
	@commands.guild_only()
	@commands.check(has_guild)
	async def deposit(self, ctx, size: int):
		"""Положить деньги в гильдию"""
		cfg = self.config
		currency = await bank.get_currency_name(ctx.guild)
		role = await cfg.member(ctx.author).guild()
		one = int(await cfg.custom("Guilds", role).guildmoney())
		two = size
		money = one + two
		try:
			await bank.withdraw_credits(ctx.author, size)
		except ValueError:
			return await ctx.send(f"У тебя нету столько {currency}!")
		await cfg.custom("Guilds", role).guildmoney.set(money)
		await ctx.send(
			f"Вы положили {two}{currency} в гильдию."
		)
	@guild.command()
	@commands.guild_only()
	@commands.check(has_guild)
	async def leave(self, ctx):
		"""Вийти с гильдии"""
		cfg = self.config
		member = ctx.author
		govno = await self.config.member(ctx.author).guildrole()
		if govno == "Owner":
			await ctx.send(
				"У тебя нет прав"
			)
			return
		else:
			pass
		guild = await cfg.member(ctx.author).guild()
		guild = ctx.guild.get_role(guild)
		await cfg.member(ctx.author).clear()
		await member.remove_roles(guild, reason=get_audit_reason(ctx.author, ("Guilds")))
		await ctx.send(
			"Ви покинули гильдию."
		)
	@guild.command()
	@commands.guild_only()
	@commands.check(has_guild)
	async def withdraw(self, ctx, size: int):
		"""Вывод средств"""
		cfg = self.config
		currency = await bank.get_currency_name(ctx.guild)
		role = await cfg.member(ctx.author).guild()
		one = int(await cfg.custom("Guilds", role).guildmoney())
		two = size
		lol = one - two
		if lol < 1:
			await ctx.send(
				f"На балансе гильдии не достаточно {currency}"
				)
			return
		else:
			await ctx.send(
				f"Вы вивели {lol}{currency}"
				)
	@guild.command()
	@commands.guild_only()
	@commands.check(has_guild)
	async def balance(self, ctx):
		"""Баланс Гильдии"""
		cfg = self.config
		currency = await bank.get_currency_name(ctx.guild)
		role = await cfg.member(ctx.author).guild()
		balance = int(await cfg.custom("Guilds", role).guildmoney())
		await ctx.send(
			f"На балансе гильдии {balance}{currency}."
		)

	@guild.command()
	@commands.guild_only()
	@commands.check(has_guild)
	async def info(self, ctx):
		"""Информация О Гильдии"""
	@guild.command()
	@commands.guild_only()
	@commands.check(has_guild)
	async def list(self, ctx):
		"""Список Учасников"""
		cfg = self.config
		role = await cfg.member(ctx.author).guild()
		members = await cfg.custom("Guilds", role).members()
		guilds = []
		dic = {
			("User"): ctx.guild.get_member(members)
						or f"[X] {await self.bot.fetch_user(members)}"
		}
		guilds.append(dic)
		pages = list(
			chat.pagify(tabulate(guilds, headers="keys", tablefmt="orgtbl"))
		)
		pages = [chat.box(page) for page in pages]
		await menu(ctx, pages, DEFAULT_CONTROLS)
	@guild.command()
	@commands.guild_only()
	@checks.admin_or_permissions(manage_roles=True)
	async def cost(self, ctx, cost: int):
		"""Настройка Цены на создания гильдии"""
		cfg = self.config
		await cfg.guild(ctx.guild).cost.set(cost)
		lol = "<:vikaSex:609762787014606879>"
		await ctx.send(f"{lol}")
	@guild.command()
	@commands.guild_only()
	@checks.admin_or_permissions(manage_roles=True)
	async def pos(self, ctx, pos: int):
		"""Настройка Позиции ролей"""
		cfg = self.config
		await cfg.guild(ctx.guild).pos.set(pos)
		lol = "<:vikaSex:609762787014606879>"
		await ctx.send(f"{lol}")