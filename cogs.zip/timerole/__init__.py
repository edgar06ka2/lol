from .timerole import Timerole


def setup(bot):
    bot.add_cog(Timerole(bot))
