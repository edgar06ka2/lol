from .personalroles1 import PersonalRoles


def setup(bot):
    bot.add_cog(PersonalRoles(bot))
