from .imperialtoolkit import ImperialToolkit


def setup(bot):
    bot.add_cog(ImperialToolkit(bot))
